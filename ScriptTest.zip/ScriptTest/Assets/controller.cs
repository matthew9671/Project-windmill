﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class controller : MonoBehaviour {

	bool mouseDown = false;
	Vector3 mousePos;
	const int sides = 4;
	const float acc = 0.5f;
	const float maxV = 8f;
	const float damp = 0.85f;
	const float sec_damp = 0.02f;
	const float v_threshold = 1f;
	const float diff_threshold = 2f;
	public float v;
	public float diff = 0f;
	float dragSpeed = 1f;
	Transform currObj;
	[SerializeField] GameObject table;
	[SerializeField] GameObject tableCenter;

	// Indicator related
	const int scanSteps = 10;
	const float range = 2.0f;
	Dictionary<GameObject, int> indicatorWeights = new Dictionary<GameObject, int>();
	[SerializeField] Texture2D indicator;
	const float indicatorSize = 30f;

	void Update () 
	{
		if (mouseDown)
		{
			diff += (mousePos.x - Input.mousePosition.x) * dragSpeed;
			mousePos = Input.mousePosition;
			smooth_interpolation(diff, false);
			diff -= v;
			table.transform.Rotate(0f, v, 0f);
		}
		else
		{
			smooth_interpolation(diff, true);
			diff -= v;
			table.transform.Rotate(0f, v, 0f);
		}
		// Use raycast for highlighting objects
		Ray ray;
		RaycastHit hit;
		indicatorWeights.Clear();
		for (int i = 1; i < scanSteps + 1; i++)
		{
			for (int dir = 0; dir < 2; dir++)
			{
				Vector3 rayPoint = new Vector3(Mathf.Lerp(Screen.width * dir, Screen.width/2, (float)i / (float)scanSteps), Screen.height / 2, range);
				rayPoint = Camera.main.ScreenToWorldPoint(rayPoint);
				ray = new Ray(rayPoint, tableCenter.transform.position - rayPoint);
				Debug.DrawRay(rayPoint, tableCenter.transform.position - rayPoint);
				Physics.Raycast(ray, out hit, Vector3.Magnitude(tableCenter.transform.position - rayPoint), 
					layerMask:LayerMask.GetMask("Table"));
				if (hit.collider != null)
				{
					GameObject curr = hit.collider.gameObject;
					indicatorWeights[curr] = i;
				}
			}
		}
	}

	void OnGUI()
	{
		foreach(GameObject obj in indicatorWeights.Keys)
		{
			Vector3 center = Camera.main.WorldToScreenPoint(obj.transform.position);
			float size = indicatorSize * indicatorWeights[obj] / scanSteps;
			Rect bounds = new Rect (center.x - size / 2, 
				Screen.height - center.y - size / 2,
									size, size);
			GUI.DrawTexture (bounds, indicator);
		}
	}

	void smooth_interpolation (float diff, bool inertia)
	// Assume that the numbers for start and target wrap around (180 = -180)
	{
		if (inertia)
		{
			float dir = Mathf.Sign(diff);
			v = v * damp - v * Mathf.Abs(v) * sec_damp + dir * acc;
			v = Mathf.Clamp(v, -maxV, maxV);
			if (Mathf.Abs(v) < v_threshold && Mathf.Abs(diff) < diff_threshold)
			{
				v = diff;
			}
		}
		else
		{
			// There is no overshooting when we are dragging by hand
			if (maxV > Mathf.Abs(diff))
			{
				v = diff;
			}
			else
			{
				v = maxV * Mathf.Sign(diff);
			}
		}
	}

	void OnMouseDown()
	{
		mouseDown = true;
		mousePos = Input.mousePosition;
	}

	float float_mod(float a, float b)
	// Assuming b > 0
	// Returns m so that 0 <= m < b and a = r * b + m where r is integer
	// Somehow the built-in mod doesn't do this??
	{
		if (a > 0)
		{
			return a % b;
		}
		else
		{
			return a % b + b;
		}
	}

	float clamp_angle(float ang)
	// Return the equivalent of ang in [-180, 180)
	{
		return float_mod(ang + 180f, 360f) - 180f;
	}

	void OnMouseUp()
	{
		float currAng = table.transform.rotation.eulerAngles.y;
		diff = Mathf.DeltaAngle(currAng, 0f);
		for (int i = 1; i < sides; i++)
		{
			float ang = 360f / sides * i;
			float angDiff = Mathf.DeltaAngle(currAng, ang);
			if (Mathf.Abs(angDiff) < Mathf.Abs(diff)) diff = angDiff;
		}
		//diff = clamp_angle(diff);
		mouseDown = false;
	}

}
